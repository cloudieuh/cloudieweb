These email templates are compiled using __heml__.  
Update these templates at https://heml.io/editor.

Learn more about email templates in the [Netlify Docs](https://www.netlify.com/docs/identity/#email-templates).
